package be.kuleuven.pylos.gui;

public class PylosGuiMain {
    public static void main(String[] args) {
        PylosGuiApplication.launchGui(args);
    }
}
