# ai_pylos

Pylos Project for labs Artificial Intelligence
